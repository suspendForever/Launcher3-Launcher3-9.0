package com.example.dragdemo.drag;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.graphics.PointF;

public class LauncherAppWidgetHostView extends AppWidgetHostView {

    private float mScaleToFit=1.2f;
    private final PointF mTranslationForCentering=new PointF();

    public LauncherAppWidgetHostView(Context context) {
        super(context);
    }

    public void setScaleToFit(float scale) {
        mScaleToFit = scale;
        setScaleX(scale);
        setScaleY(scale);
    }

    public float getScaleToFit() {
        return mScaleToFit;
    }

    public void setTranslationForCentering(float x, float y) {
        mTranslationForCentering.set(x, y);
        setTranslationX(x);
        setTranslationY(y);
    }

    public PointF getTranslationForCentering()



    {
        return mTranslationForCentering;
    }


}