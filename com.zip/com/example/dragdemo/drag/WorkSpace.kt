package com.example.dragdemo.drag

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.FrameLayout

class WorkSpace : FrameLayout, DragSource {

    private lateinit var mDragController: DragController
    private var mDragSourceInternal: WidgetContainer? = null
    private var mOutlineProvider: DragPreviewProvider? = null

    private var mDragInfo: CellLayout.CellInfo? = null

    private val mTempXY = IntArray(2)

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    fun setup(dragController: DragController) {
        mDragController = dragController

        // hardware layers on children are enabled on startup, but should be disabled until
        // needed
        updateChildrenLayersEnabled()
    }

    fun startDrag(cellInfo: CellLayout.CellInfo) {
        Log.d(TAG, "startDrag: ")
        val child: View = cellInfo.cell
        mDragInfo = cellInfo
        //将长按的view设为不可见
        child.visibility = INVISIBLE
        beginDragShared(child, this)
    }

    fun beginDragShared(child: View, source: DragSource?) {
        val dragObject = child.tag
        if (dragObject !is ItemInfo) {
            throw IllegalStateException("fuck")
        }
        beginDragShared(child, source, dragObject, DragPreviewProvider(child))
    }

    fun beginDragShared(
        child: View,
        source: DragSource?,
        dragObject: ItemInfo,
        previewProvider: DragPreviewProvider
    ) :DragView{
        val iconScale = 1f
        child.clearFocus()
        child.isPressed = false
        mOutlineProvider = previewProvider

        val b = previewProvider.createDragBitmap()

        val scale = previewProvider.getScaleAndPosition(b, mTempXY)
        val dragLayerX = mTempXY[0]
        val dragLayerY = mTempXY[1]


        //对于widget来说没啥用 --
        //对于widget来说没啥用 ++
        if (child.parent is WidgetContainer) {
            mDragSourceInternal = child.parent as WidgetContainer
        }

        //对于widget来说没啥用 --
        val dv: DragView = mDragController.startDrag(
            b, dragLayerX, dragLayerY, source,
            dragObject, null, null, scale * iconScale, scale)
        return dv

    }

    companion object {
        private const val TAG = "WorkSpace"
    }

    override fun onDropCompleted(target: View?, d: DragObject?, success: Boolean) {

    }
}