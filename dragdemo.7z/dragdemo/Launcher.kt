package com.example.dragdemo

import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.dragdemo.drag.BaseDragLayer
import com.example.dragdemo.drag.DragController
import com.example.dragdemo.drag.ILauncher
import com.example.dragdemo.drag.WorkSpace

class Launcher : AppCompatActivity(), ILauncher {

    private var mWorkspace: WorkSpace? = null

    private var mDragController: DragController? = null

    private var mWorkSpace: WorkSpace? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mDragController = DragController(this)
        mWorkSpace=findViewById(R.id.workspace)
        mDragController?.addDragListener(mWorkspace)

    }

    fun getWorkSpace(): WorkSpace? {
        return mWorkspace
    }

    companion object {
        private const val TAG = "Launcher"

        @JvmStatic
        fun getLauncher(context: Context): Launcher {
            return if (context is Launcher) {
                context
            } else (context as ContextWrapper).baseContext as Launcher
        }
    }

    override fun finishAutoCancelActionMode(): Boolean {
        TODO("Not yet implemented")
    }

    override fun getContext(): Context {
        TODO("Not yet implemented")
    }

    override fun getDragLayer(): BaseDragLayer<*> {
        TODO("Not yet implemented")
    }

    override fun getRootView(): View {
        TODO("Not yet implemented")
    }

    override fun getDragController(): DragController {
        TODO("Not yet implemented")
    }


}