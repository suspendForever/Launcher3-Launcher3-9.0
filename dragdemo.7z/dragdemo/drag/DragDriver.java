package com.example.dragdemo.drag;

import android.content.Context;
import android.view.DragEvent;
import android.view.MotionEvent;

public abstract class DragDriver {

    private static final String TAG = "DragDriver";

    private final EventListener mEventListener;

    public void onDragViewAnimationEnd() {

    }

    public interface EventListener {
        void onDriverDragMove(float x, float y);

        void onDriverDragExitWindow();

        void onDriverDragEnd(float x, float y);

        void onDriverDragCancel();
    }

    public abstract boolean onDragEvent(DragEvent event);

    public DragDriver(EventListener eventListener) {
        mEventListener = eventListener;
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        LogUtil.d(TAG, "onInterceptTouchEvent: action:" + ev.getAction());
        final int action = ev.getAction();

        switch (action) {
            case MotionEvent.ACTION_UP:
                mEventListener.onDriverDragEnd(ev.getX(), ev.getY());
                break;
            case MotionEvent.ACTION_CANCEL:
                mEventListener.onDriverDragCancel();
                break;
        }

        return true;
    }

    public static DragDriver create(Context context, DragController dragController,
                                    DropTarget.DragObject dragObject) {
        return new InternalDragDriver(dragController);
    }


}

class InternalDragDriver extends DragDriver {

    private static final String TAG = "InternalDragDriver";

    InternalDragDriver(DragController dragController) {
        super(dragController);
        LogUtil.d(TAG, "InternalDragDriver: constructor");
    }

    @Override
    public boolean onDragEvent(DragEvent event) {
        return false;
    }
}
