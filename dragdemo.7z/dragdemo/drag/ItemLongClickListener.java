package com.example.dragdemo.drag;

import android.view.View;

import com.example.dragdemo.Launcher;

public class ItemLongClickListener {

    private static final String TAG = "ItemLongClickListener";
    private static boolean onWorkspaceItemLongClick(View v) {
        LogUtil.d(TAG, "onWorkspaceItemLongClick: ");
        Launcher launcher = Launcher.Companion.getLauncher(v.getContext());
        if (!canStartDrag(launcher)) {
            LogUtil.d(TAG, "onWorkspaceItemLongClick: can not StartDrag");
            return false;
        }


        if (!(v.getTag() instanceof ItemInfo)) return false;

//        launcher.setWaitingForResult(null);
        beginDrag(v, launcher, (ItemInfo) v.getTag());
        return true;
    }

    public static void beginDrag(View v, Launcher launcher, ItemInfo info) {
        LogUtil.d(TAG, "beginDrag: ");
        CellLayout.CellInfo longClickCellInfo = new CellLayout.CellInfo(v, info);
        launcher.getWorkSpace().startDrag(longClickCellInfo);
    }

    public static boolean canStartDrag(ILauncher launcher) {
        if (launcher == null) {
            return false;
        }
        // We prevent dragging when we are loading the workspace as it is possible to pick up a view
        // that is subsequently removed from the workspace in startBinding().
//        if (launcher.isWorkspaceLocked()) return false;


        // Return early if an item is already being dragged (e.g. when long-pressing two shortcuts)
        if (launcher.getDragController().isDragging()) return false;

        return true;
    }
}
