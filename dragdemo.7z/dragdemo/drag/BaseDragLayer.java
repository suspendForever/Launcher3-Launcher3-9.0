package com.example.dragdemo.drag;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class BaseDragLayer<T extends ILauncher> extends FrameLayout {

    private static final String TAG = "LhmBaseDragLayer";

    private TouchCompleteListener mTouchCompleteListener;

    protected TouchController mActiveController;

    protected TouchController[] mTouchControllers;

    protected final T mActivity;

    public BaseDragLayer(@NonNull Context context) {
        super(context);
        mActivity = (T) context;
    }

    public BaseDragLayer(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mActivity = (T) context;
    }

    public BaseDragLayer(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mActivity = (T) context;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        LogUtil.d(TAG, "onInterceptTouchEvent: " + ev.getAction());
        //DragLayer派发事件 包括拖拽view有关的一系列事件
        int action = ev.getAction();

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (mTouchCompleteListener != null) {
                mTouchCompleteListener.onTouchComplete();
            }
            mTouchCompleteListener = null;
        }

        boolean hasFind = findActiveController(ev);
        LogUtil.d(TAG, "onInterceptTouchEvent: findController " + hasFind);
        //当触发了拖动后拦截此事件 自己处理
        return hasFind;
    }

    protected boolean findActiveController(MotionEvent event) {
        mActiveController = null;

        for (TouchController controller : mTouchControllers) {
            if (controller.onControllerTouchEvent(event)) {
                mActiveController = controller;
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (mTouchCompleteListener != null) {
                mTouchCompleteListener.onTouchComplete();
            }
            mTouchCompleteListener = null;
        }

        if (mActiveController != null) {
            return mActiveController.onControllerTouchEvent(event);
        } else {
            return findActiveController(event);
        }

    }

    public float getLocationInDragLayer(View child, int[] loc) {
        loc[0] = 0;
        loc[1] = 0;
        return getDescendantCoordRelativeToSelf(child, loc);
    }

    public float getDescendantCoordRelativeToSelf(View descendant, int[] coord) {
        return getDescendantCoordRelativeToSelf(descendant, coord, false);
    }

    public float getDescendantCoordRelativeToSelf(View descendant, int[] coord,
                                                  boolean includeRootScroll) {
        return Utils.getDescendantCoordRelativeToAncestor(descendant, this,
                coord, includeRootScroll);
    }

    public void mapCoordInSelfToDescendant(View descendant, int[] coord) {
        Utils.mapCoordInSelfToDescendant(descendant, this, coord);
    }

    public interface TouchCompleteListener {
        void onTouchComplete();
    }

    public static class LayoutParams extends FrameLayout.LayoutParams {
        public int x, y;
        public boolean customPosition = false;

        public LayoutParams(Context c, AttributeSet attrs) {
            super(c, attrs);
        }

        public LayoutParams(int width, int height) {
            super(width, height);
        }

        public LayoutParams(ViewGroup.LayoutParams lp) {
            super(lp);
        }

        public void setWidth(int width) {
            this.width = width;
        }

        public int getWidth() {
            return width;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public int getHeight() {
            return height;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getX() {
            return x;
        }

        public void setY(int y) {
            this.y = y;
        }

        public int getY() {
            return y;
        }
    }
}
