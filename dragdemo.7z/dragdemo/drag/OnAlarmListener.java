package com.example.dragdemo.drag;

public interface OnAlarmListener {
    public void onAlarm(Alarm alarm);
}