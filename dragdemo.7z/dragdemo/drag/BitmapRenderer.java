package com.example.dragdemo.drag;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.os.Build;

public class BitmapRenderer {


     private static final boolean USE_HARDWARE_BITMAP =  Build.VERSION.SDK_INT >= Build.VERSION_CODES.P;;

     public static Bitmap createSoftwareBitmap(int width, int height, Renderer renderer) {
          Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
          renderer.draw(new Canvas(result));
          return result;
     }

     @TargetApi(Build.VERSION_CODES.P)
     public static Bitmap createHardwareBitmap(int width, int height, Renderer renderer) {
          if (!USE_HARDWARE_BITMAP) {
               return createSoftwareBitmap(width, height, renderer);
          }

          Picture picture = new Picture();
          renderer.draw(picture.beginRecording(width, height));
          picture.endRecording();
          return Bitmap.createBitmap(picture);
     }

     /**
      * Interface representing a bitmap draw operation.
      */
     public interface Renderer {
          void draw(Canvas out);
     }
}