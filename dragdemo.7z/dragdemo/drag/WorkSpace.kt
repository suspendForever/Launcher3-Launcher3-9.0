package com.example.dragdemo.drag

import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import com.example.dragdemo.Launcher

class WorkSpace : FrameLayout, DragSource, DropTarget {

    private lateinit var mLauncher: Launcher
    private var mAddToExistingFolderOnDrop: Boolean = false
    private var mCreateUserFolderOnDrop: Boolean = false
    private lateinit var mDragController: DragController
    private var mDragSourceInternal: WidgetContainer? = null
    private var mOutlineProvider: DragPreviewProvider? = null

    private var mDropToLayout: CellLayout? = null

    var mDragViewVisualCenter = FloatArray(2)

    private var mDragInfo: CellLayout.CellInfo? = null

    var mDragTargetLayout: CellLayout? = null

    var mLastReorderX = -1

    var mLastReorderY = -1

    private var mDragOverX = -1
    private var mDragOverY = -1

    private val mReorderAlarm = Alarm()


    private val mTempXY = IntArray(2)

    private val DRAG_MODE_NONE = 0
    private val DRAG_MODE_CREATE_FOLDER = 1
    private val DRAG_MODE_ADD_TO_FOLDER = 2
    private val DRAG_MODE_REORDER = 3

    private var mDragMode: Int = DRAG_MODE_NONE

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        mLauncher = Launcher.getLauncher(context)
    }

    fun setup(dragController: DragController) {
        mDragController = dragController

        // hardware layers on children are enabled on startup, but should be disabled until
        // needed
        updateChildrenLayersEnabled()
    }

    fun startDrag(cellInfo: CellLayout.CellInfo) {
        Log.d(TAG, "startDrag: ")
        val child: View = cellInfo.cell
        mDragInfo = cellInfo
        //将长按的view设为不可见
        child.visibility = INVISIBLE
        beginDragShared(child, this)
    }

    fun beginDragShared(child: View, source: DragSource?) {
        val dragObject = child.tag
        if (dragObject !is ItemInfo) {
            throw IllegalStateException("fuck")
        }
        beginDragShared(child, source, dragObject, DragPreviewProvider(child))
    }

    fun beginDragShared(
        child: View,
        source: DragSource?,
        dragObject: ItemInfo,
        previewProvider: DragPreviewProvider
    ): DragView {
        val iconScale = 1f
        child.clearFocus()
        child.isPressed = false
        mOutlineProvider = previewProvider

        val b = previewProvider.createDragBitmap()

        val scale = previewProvider.getScaleAndPosition(b, mTempXY)
        val dragLayerX = mTempXY[0]
        val dragLayerY = mTempXY[1]


        //对于widget来说没啥用 --
        //对于widget来说没啥用 ++
        if (child.parent is WidgetContainer) {
            mDragSourceInternal = child.parent as WidgetContainer
        }

        //对于widget来说没啥用 --
        val dv: DragView = mDragController.startDrag(
            b, dragLayerX, dragLayerY, source,
            dragObject, null, null, scale * iconScale, scale
        )
        return dv

    }

    companion object {
        private const val TAG = "WorkSpace"
    }

    override fun onDropCompleted(target: View?, d: DragObject?, success: Boolean) {

    }

    override fun isDropEnabled(): Boolean {
        TODO("Not yet implemented")
    }

    override fun onDrop(dragObject: DropTarget.DragObject?) {
        TODO("Not yet implemented")
    }

    override fun onDragEnter(dragObject: DropTarget.DragObject) {
        mCreateUserFolderOnDrop = false
        mAddToExistingFolderOnDrop = false

        mDropToLayout = null
        mDragViewVisualCenter = dragObject.getVisualCenter(mDragViewVisualCenter)
        setDropLayoutForDragObject(dragObject, mDragViewVisualCenter.get(0), mDragViewVisualCenter.get(1))
    }

    private fun setDropLayoutForDragObject(
        d: DropTarget.DragObject,
        centerX: Float,
        centerY: Float
    ): Boolean {
        var layout: CellLayout? = null
        // Test to see if we are over the hotseat first

        val nextPage: Int = 0

        layout = getChildAt(nextPage) as CellLayout
        if (layout !== mDragTargetLayout) {
            setCurrentDropLayout(layout)
//            setCurrentDragOverlappingLayout(layout)
            return true
        }
        return false
    }

    fun setCurrentDropLayout(layout: CellLayout?) {
        if (mDragTargetLayout != null) {
            mDragTargetLayout!!.revertTempState()
            mDragTargetLayout!!.onDragExit()
        }
        mDragTargetLayout = layout
        if (mDragTargetLayout != null) {
            mDragTargetLayout!!.onDragEnter()
        }
        cleanupReorder(true)
        setCurrentDropOverCell(-1, -1)
    }

    fun setCurrentDropOverCell(x: Int, y: Int) {
        if (x != mDragOverX || y != mDragOverY) {
            mDragOverX = x
            mDragOverY = y
            setDragMode(DRAG_MODE_NONE)
        }
    }

    fun setDragMode(dragMode: Int) {
        if (dragMode != mDragMode) {
            if (dragMode == DRAG_MODE_NONE) {
                // We don't want to cancel the re-order alarm every time the target cell changes
                // as this feels to slow / unresponsive.
                cleanupReorder(false)

            } else if (dragMode == DRAG_MODE_ADD_TO_FOLDER) {
                cleanupReorder(true)

            } else if (dragMode == DRAG_MODE_CREATE_FOLDER) {

                cleanupReorder(true)
            } else if (dragMode == DRAG_MODE_REORDER) {

            }
            mDragMode = dragMode
        }
    }

    private fun cleanupReorder(cancelAlarm: Boolean) {
        // Any pending reorders are canceled
        if (cancelAlarm) {
            mReorderAlarm.cancelAlarm()
        }
        mLastReorderX = -1
        mLastReorderY = -1
    }


    override fun onDragOver(dragObject: DropTarget.DragObject?) {
        TODO("Not yet implemented")
    }

    override fun onDragExit(dragObject: DropTarget.DragObject?) {
        TODO("Not yet implemented")
    }

    override fun acceptDrop(dragObject: DropTarget.DragObject?): Boolean {
        TODO("Not yet implemented")
    }

    override fun prepareAccessibilityDrop() {
        TODO("Not yet implemented")
    }

    override fun getHitRectRelativeToDragLayer(outRect: Rect?) {
        TODO("Not yet implemented")
    }
}