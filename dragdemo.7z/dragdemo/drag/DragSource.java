package com.example.dragdemo.drag;

import android.view.View;

public interface DragSource {

    /**
     * A callback made back to the source after an item from this source has been dropped on a
     * DropTarget.
     */
    void onDropCompleted(View target, DragObject d, boolean success);
}