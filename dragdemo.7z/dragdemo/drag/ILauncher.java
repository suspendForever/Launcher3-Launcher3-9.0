package com.example.dragdemo.drag;

import android.content.Context;
import android.view.View;

public interface ILauncher {
    Boolean finishAutoCancelActionMode();

    Context getContext();

    BaseDragLayer getDragLayer();

//    LhmDragController getDragController();

    View getRootView();

    DragController getDragController();

//    LhmDropTarget getDropTarget();
}